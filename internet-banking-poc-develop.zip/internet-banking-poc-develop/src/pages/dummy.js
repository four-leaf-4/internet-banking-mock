import React from "react";
import { Box, Typography } from "@material-ui/core";

export default function Home() {
  return (
    <Box>
      <Typography>
        このページはダミーです。外部リンクを想定しています。
      </Typography>
    </Box>
  );
}
