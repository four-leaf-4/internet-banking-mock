import React from "react";
import { Box } from "@material-ui/core";
import { MailNoticesSettingForm } from "./molecular/mailnoticessettingform";

export const MailNoticesCategories = () => {
  return (
    <Box>
      <MailNoticesSettingForm />
    </Box>
  );
};
