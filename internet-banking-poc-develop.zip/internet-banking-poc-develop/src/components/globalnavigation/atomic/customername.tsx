import React from "react";
import { Typography } from "@material-ui/core";

export const Customername = () => {
  return (
    <Typography variant="caption" component="p">
      xxxxxx様
    </Typography>
  );
};

export default Customername;
