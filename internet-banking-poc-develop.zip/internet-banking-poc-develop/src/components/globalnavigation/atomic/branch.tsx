import React from "react";
import { Typography } from "@material-ui/core";

export const Branch = () => {
  return (
    <Typography variant="caption" component="p">
      支店名xxx
    </Typography>
  );
};

export default Branch;
