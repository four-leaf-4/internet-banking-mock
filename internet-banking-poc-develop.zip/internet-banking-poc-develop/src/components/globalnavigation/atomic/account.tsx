import React from "react";
import { Typography } from "@material-ui/core";

export const Account = () => {
  return (
    <Typography variant="caption" component="p">
      普通預金xxxxxx
    </Typography>
  );
};

export default Account;
