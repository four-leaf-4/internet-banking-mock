import React from "react";
import { Typography } from "@material-ui/core";

export const Balance = (prop) => {
  return <Typography>{prop.value}</Typography>;
};

export default Balance;
