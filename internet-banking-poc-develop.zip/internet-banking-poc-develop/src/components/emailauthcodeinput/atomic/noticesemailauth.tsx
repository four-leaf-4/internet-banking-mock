import React from "react";
import { Typography } from "@material-ui/core";

export const NoticesEmailAuth = () => {
  return (
    <Typography>
      注意事項注意事項注意事項注意事項注意事項注意事項注意事項注意事項
    </Typography>
  );
};
