import React from "react";
// import { Logolink } from "../atomic/logolink"
import { Btnlogout } from "../atomic/btnlogout";

export const Contentheader = () => {
  return (
    <>
      <Btnlogout />
    </>
  );
};
