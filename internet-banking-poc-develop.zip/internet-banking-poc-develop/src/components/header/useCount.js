import React, { useState } from "react";

export function useCount() {
  const [count, setCount] = useState(0);
}
